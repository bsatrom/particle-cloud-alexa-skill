// Particle API Utility functions for My Particle Alexa Skill

const fetchDevice = (token, name) => {
  
}

exports.utils = {
  fetchDevice
}