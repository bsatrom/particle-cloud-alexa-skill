# MyParticle
Alexa Skill Lambda Function for accessing Particle devices
